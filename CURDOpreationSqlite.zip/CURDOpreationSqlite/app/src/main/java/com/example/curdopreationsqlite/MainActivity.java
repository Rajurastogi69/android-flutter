package com.example.curdopreationsqlite;


import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText etName, etEmail, etPhone;
    Button btnInsert, btnUpdate, btnDelete, btnClear;
    ListView listView;
    TextView tvListLabel;

    DBHelper dbHelper;
    ArrayAdapter<String> adapter;
    ArrayList<String> displayList;    // strings to show in ListView
    ArrayList<Long> idList;           // parallel list of ids

    long selectedId = -1; // currently selected record id (-1 = none)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // ensure layout name matches

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);

        btnInsert = findViewById(R.id.btnInsert);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        btnClear = findViewById(R.id.btnClear);

        listView = findViewById(R.id.listView);
        tvListLabel = findViewById(R.id.tvListLabel);

        dbHelper = new DBHelper(this);
        displayList = new ArrayList<>();
        idList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, displayList);
        listView.setAdapter(adapter);

        // Load existing records
        loadData();

        btnInsert.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();

            if (name.isEmpty()) {
                Toast.makeText(this, "Enter name", Toast.LENGTH_SHORT).show();
                return;
            }

            long id = dbHelper.insert(name, email, phone);
            if (id != -1) {
                Toast.makeText(this, "Inserted", Toast.LENGTH_SHORT).show();
                clearFields();
                loadData();
            } else {
                Toast.makeText(this, "Insert failed", Toast.LENGTH_SHORT).show();
            }
        });

        btnUpdate.setOnClickListener(v -> {
            if (selectedId == -1) {
                Toast.makeText(this, "Select a record to update", Toast.LENGTH_SHORT).show();
                return;
            }
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();

            int rows = dbHelper.update(selectedId, name, email, phone);
            if (rows > 0) {
                Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                clearFields();
                loadData();
            } else {
                Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
            }
        });

        btnDelete.setOnClickListener(v -> {
            if (selectedId == -1) {
                Toast.makeText(this, "Select a record to delete", Toast.LENGTH_SHORT).show();
                return;
            }
            int rows = dbHelper.delete(selectedId);
            if (rows > 0) {
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                clearFields();
                loadData();
            } else {
                Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
            }
        });

        btnClear.setOnClickListener(v -> clearFields());

        // When user clicks a list item, populate fields and mark selectedId
        listView.setOnItemClickListener((parent, view, position, id) -> {
            selectedId = idList.get(position);
            // fetch the full record (optional)
            Cursor c = dbHelper.getById(selectedId);
            if (c != null) {
                if (c.moveToFirst()) {
                    String name = c.getString(c.getColumnIndexOrThrow(DBHelper.COL_NAME));
                    String email = c.getString(c.getColumnIndexOrThrow(DBHelper.COL_EMAIL));
                    String phone = c.getString(c.getColumnIndexOrThrow(DBHelper.COL_PHONE));
                    etName.setText(name);
                    etEmail.setText(email);
                    etPhone.setText(phone);
                }
                c.close();
            }
        });
    }

    private void loadData() {
        displayList.clear();
        idList.clear();

        Cursor cursor = dbHelper.getAll();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(DBHelper.COL_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_NAME));
                String email = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_EMAIL));
                String phone = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_PHONE));

                displayList.add(id + " | " + name + " | " + email + " | " + phone);
                idList.add(id);
            }
            cursor.close();
        }
        adapter.notifyDataSetChanged();
        selectedId = -1;
    }

    private void clearFields() {
        etName.setText("");
        etEmail.setText("");
        etPhone.setText("");
        selectedId = -1;
        listView.clearChoices();
        adapter.notifyDataSetChanged();
    }
}
