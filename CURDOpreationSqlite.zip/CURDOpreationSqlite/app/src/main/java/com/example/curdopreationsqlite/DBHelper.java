package com.example.curdopreationsqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "MyAppDB.db";
    private static final int DB_VERSION = 1;
    public static final String TABLE = "contacts";
    public static final String COL_ID = "_id"; // use _id for cursor compatibility
    public static final String COL_NAME = "name";
    public static final String COL_EMAIL = "email";
    public static final String COL_PHONE = "phone";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABLE + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NAME + " TEXT, " +
                COL_EMAIL + " TEXT, " +
                COL_PHONE + " TEXT)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    // Insert
    public long insert(String name, String email, String phone) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_NAME, name);
        cv.put(COL_EMAIL, email);
        cv.put(COL_PHONE, phone);
        return db.insert(TABLE, null, cv);
    }

    // Update by id
    public int update(long id, String name, String email, String phone) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_NAME, name);
        cv.put(COL_EMAIL, email);
        cv.put(COL_PHONE, phone);
        String where = COL_ID + "=?";
        String[] args = { String.valueOf(id) };
        return db.update(TABLE, cv, where, args);
    }

    // Delete by id
    public int delete(long id) {
        SQLiteDatabase db = getWritableDatabase();
        String where = COL_ID + "=?";
        String[] args = { String.valueOf(id) };
        return db.delete(TABLE, where, args);
    }

    // Get all records (caller must close cursor)
    public Cursor getAll() {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(TABLE, null, null, null, null, null, COL_ID + " DESC");
    }

    // Get single record by id
    public Cursor getById(long id) {
        SQLiteDatabase db = getReadableDatabase();
        String where = COL_ID + "=?";
        String[] args = { String.valueOf(id) };
        return db.query(TABLE, null, where, args, null, null, null);
    }
}
