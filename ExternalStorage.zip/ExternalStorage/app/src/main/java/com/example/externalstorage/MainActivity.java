package com.example.externalstorage;


import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    EditText etText;
    Button btnWrite;
    TextView tvOutput;

    String FILE_NAME = "MyDownloadFile.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etText = findViewById(R.id.etText);
        btnWrite = findViewById(R.id.btnWrite);
        tvOutput = findViewById(R.id.tvOutput);

        btnWrite.setOnClickListener(v -> saveToDownloads());
    }

    private void saveToDownloads() {
        String data = etText.getText().toString();

        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, FILE_NAME);
        values.put(MediaStore.Downloads.MIME_TYPE, "text/plain");

        // Save inside Download folder (Android 10+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.put(MediaStore.Downloads.RELATIVE_PATH, "Download/");
        }

        Uri uri = getContentResolver()
                .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);

        if (uri == null) {
            Toast.makeText(this, "Error creating file", Toast.LENGTH_SHORT).show();
            return;
        }

        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            out.write(data.getBytes());
            Toast.makeText(this, "Saved to Downloads folder!", Toast.LENGTH_LONG).show();
            tvOutput.setText("Saved file: " + FILE_NAME);
        } catch (Exception e) {
            Toast.makeText(this, "Error writing file!", Toast.LENGTH_SHORT).show();
        }
    }
}
