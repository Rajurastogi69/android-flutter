package com.example.backgroundchangeradio;


import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    RadioGroup radioGroup;
    RadioButton radioRed, radioGreen, radioBlue;
    LinearLayout mainLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainLayout = findViewById(R.id.mainLayout);
        radioGroup = findViewById(R.id.radioGroup);

        radioRed = findViewById(R.id.radioRed);
        radioGreen = findViewById(R.id.radioGreen);
        radioBlue = findViewById(R.id.radioBlue);

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioRed) {
                mainLayout.setBackgroundColor(Color.RED);
            } else if (checkedId == R.id.radioGreen) {
                mainLayout.setBackgroundColor(Color.GREEN);
            } else if (checkedId == R.id.radioBlue) {
                mainLayout.setBackgroundColor(Color.BLUE);
            }
        });
    }
}
