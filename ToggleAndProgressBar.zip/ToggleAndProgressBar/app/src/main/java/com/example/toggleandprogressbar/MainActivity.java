package com.example.toggleandprogressbar;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ToggleButton toggleButton;
    ProgressBar progressBar;
    Button btnIncrease, btnReset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ToggleButton
        toggleButton = findViewById(R.id.toggleButton);

        // Toggle should ONLY show ON/OFF — no progress, no spinner
        toggleButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                Toast.makeText(MainActivity.this, "Toggle is ON", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Toggle is OFF", Toast.LENGTH_SHORT).show();
            }
        });

        // ProgressBar
        progressBar = findViewById(R.id.progressBar);
        btnIncrease = findViewById(R.id.btnIncrease);
        btnReset = findViewById(R.id.btnReset);

        // Increase progress by 10%
        btnIncrease.setOnClickListener(v -> {
            int p = progressBar.getProgress();
            if (p < 100) {
                progressBar.setProgress(p + 10);
            }
        });

        // Reset to 0
        btnReset.setOnClickListener(v -> progressBar.setProgress(0));
    }
}
