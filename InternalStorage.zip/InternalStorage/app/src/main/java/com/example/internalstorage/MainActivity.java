package com.example.internalstorage;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    EditText etData;
    Button btnWrite, btnRead;
    TextView tvOutput;

    private final String FILE_NAME = "myFile.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etData = findViewById(R.id.etData);
        btnWrite = findViewById(R.id.btnWrite);
        btnRead = findViewById(R.id.btnRead);
        tvOutput = findViewById(R.id.tvOutput);

        // Write Data
        btnWrite.setOnClickListener(v -> writeData());

        // Read Data
        btnRead.setOnClickListener(v -> readData());
    }

    private void writeData() {
        String text = etData.getText().toString();

        try (FileOutputStream fos = openFileOutput(FILE_NAME, MODE_PRIVATE)) {
            fos.write(text.getBytes());
            Toast.makeText(this, "Data Saved Successfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void readData() {
        try (FileInputStream fis = openFileInput(FILE_NAME)) {
            int ch;
            StringBuilder stringBuilder = new StringBuilder();

            while ((ch = fis.read()) != -1) {
                stringBuilder.append((char) ch);
            }

            tvOutput.setText("Saved Data: " + stringBuilder.toString());

        } catch (IOException e) {
            Toast.makeText(this, "No Data Found", Toast.LENGTH_SHORT).show();
        }
    }
}
